// Node for a Binary Tree

public class Node {
    int item;
    Node left, right;

    public Node(int item) {
        this.item = item;
        left = right = null;
    }

}
