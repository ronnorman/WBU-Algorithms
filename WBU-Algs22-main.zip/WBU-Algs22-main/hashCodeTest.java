import edu.princeton.cs.algs4.StdOut;

public class hashCodeTest {
    public static void main(String[] args) {
        String s1 = "Siblings";
        String s2 = "Teheran";

        StdOut.println(s1.hashCode());
        StdOut.println(s2.hashCode());
    }
}
